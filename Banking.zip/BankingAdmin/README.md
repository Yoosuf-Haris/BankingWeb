# Smarthr---hr-payroll-project-employee-management-System

# Installation
 1. clone the repository into your desired web server.
 2. create database name 'smarthr'
 import the sql file inside the database folder
 run it on the browser and you are good to go.

 # Login Credentials
 `username`: `Vendetta`
 'password': `vendetta`
 Or
 `username`: `Barry`
`password` : `barry`

# Note
 1. a huge part of the project is still under development.most of it is still just html files and no backend has been added to it yet so feel free to fork it and contribute.And don't forget to star the repository.

# The whole project is under a complete rewrite.I am completely writing it with the laravel framework.with some new features.

Check it out here and https://github.com/MusheAbdulHakim/Laravel-Smarthr
 
#screenshots

![ScreenShot](screenshots/login.png?raw=true "Login page")
![Dashboard](screenshots/dashboard.png?raw=true "Dashbaord page")
![Dashboard](screenshots/clients.png?raw=true "Clients page")
![Dashboard](screenshots/employees.png?raw=true "employees page")
