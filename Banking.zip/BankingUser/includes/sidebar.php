<div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							<li class="menu-title"> 
								<span>Main</span>
							</li>
							<li class="submenu">
								<a href="#"><i class="la la-dashboard"></i> <span>User Dashboard</span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="employee-dashboard.php">User Dashboard</a></li>
								
								</ul>
							</li>
							
							<li class="menu-title"> 
								<span>Employees</span>
							</li>
							<li class="submenu">
								<a href="#" class="noti-dot"><i class="la la-user"></i> <span> User</span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="holidays.php">Holidays</a></li>
									<li><a href="leaves-employee.php">My Leave</a></li>
									<li><a href="departments.php">My Working Department</a></li>
									<li><a href="overtime.php">My Overtime</a></li>
								</ul>
							</li>
							
							
							
							
							<li class="submenu">
								<a href="#"><i class="la la-money"></i> <span> Payment & Salary </span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="salary.php"> My Salary </a></li>
								</ul>
							</li>
							
							
							
						
							
							
							
						
							<li class="menu-title"> 
								<span>Pages</span>
							</li>
							<li class="submenu">
								<a href="#"><i class="la la-user"></i> <span> Profile </span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="profile.php"> User Profile </a></li>
								
								</ul>
							</li>
							<li> 
								<a href="logout.php"><i class="la la-power-off"></i> <span>Logout</span></a>
							</li>
									
						</ul>
					</div>
                </div>
            </div>